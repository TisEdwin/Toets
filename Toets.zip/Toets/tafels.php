<?php

for ($x = 0; $x <= 12; $x++) {
    echo "$x x $x =" . PHP_EOL;
}

?>